[1] [2] [3] [1] [2] [3]

[looooooooooooooooooooooooooooooooooooooooooooooooooong label]

 [1]: <http://something.example.com/foo/bar>
 [2]: http://something.example.com/foo/bar 'test'
 [3]:
 http://foo/bar
 [    looooooooooooooooooooooooooooooooooooooooooooooooooong   label    ]:
 111
 'test'
 [[[[[[[[[[[[[[[[[[[[ this should not slow down anything ]]]]]]]]]]]]]]]]]]]]: q
 (as long as it is not referenced anywhere)

 [[[[[[[[[[[[[[[[[[[[]: this is not a valid reference
