#ifndef AUTOLINK_H
#define AUTOLINK_H

#include "core-extensions.h"

cmark_syntax_extension *create_autolink_extension(void);

#endif
