
const cmark = require('node-cmark');

const markdown = '# h1 title';

cmark.markdown2html(markdown);
